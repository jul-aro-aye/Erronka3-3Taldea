package erronka3;

public class Zalantza {

}
