package erronka3;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JMenuItem;

public class MenuAdminNagusia extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuAdminNagusia frame = new MenuAdminNagusia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuAdminNagusia() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 627, 362);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnKudeatu = new JMenu("Kudeatu");
		menuBar.add(mnKudeatu);
		
		JMenuItem mnLangilea = new JMenuItem("Langilea");
		mnKudeatu.add(mnLangilea);
		
		JMenuItem mnBezeroa = new JMenuItem("Bezeroa");
		mnKudeatu.add(mnBezeroa);
		
		JMenu mnOrria = new JMenu("Orria");
        menuBar.add(mnOrria);
        
        JMenuItem mnSaioaItxi = new JMenuItem("Saioa itxi");
        mnOrria.add(mnSaioaItxi);
        
        JMenuItem mnAtera = new JMenuItem("Atera");
        mnOrria.add(mnAtera);
		
		mnLangilea.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	LangileaAdminKud langileaKud = new LangileaAdminKud();
                langileaKud.setVisible(true);
                dispose();
            }
        });
		
		mnSaioaItxi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	dispose();
                Login login = new Login();
                login.setVisible(true);
            }
        });
		
		mnAtera.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAtera = new JButton("Atera");
		btnAtera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnAtera.setBackground(new Color(255, 128, 128));
		btnAtera.setBounds(230, 175, 100, 30);
		contentPane.add(btnAtera);
	}
}
