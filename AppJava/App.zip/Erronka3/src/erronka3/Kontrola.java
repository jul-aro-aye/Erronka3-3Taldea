package erronka3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Kontrola {
	public boolean loginEgin(String Erab, char[] Pasa) throws SQLException {
		boolean egoera = false;
		Konexioa konexioa = new Konexioa("jdbc:mysql://localhost:3306/3erronka", "root", "1MG2024");
		Connection konexioadb;
		
		String kontsultaErab = "SELECT erabiltzailea FROM langilea WHERE erabiltzailea = ?";

		konexioadb = konexioa.getConnection();
		
		try (PreparedStatement ps = konexioadb.prepareStatement(kontsultaErab)) {
		    ps.setString(1, Erab);

		    try (ResultSet emaitza = ps.executeQuery()) {
		        if (emaitza.next()) {
		            egoera = true;
		        }
		    }
		} catch (SQLException e1) {
		    e1.printStackTrace();
		}

		return egoera;
	}
}
