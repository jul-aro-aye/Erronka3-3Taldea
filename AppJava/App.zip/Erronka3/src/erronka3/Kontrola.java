package erronka3; 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Kontrola {
	
	public boolean langileErabiltzaileaKonprobatu(String Erab) throws SQLException {
		boolean egoera = false;
		if (Langilea.erabiltzaileaKonprobatu(Erab)) {
			egoera = true;
		}
		return egoera;
	}
	
	public boolean langileEmailaKonprobatu(String Emaila) throws SQLException {
		boolean egoera = false;
		if (Langilea.emailaKonprobatu(Emaila)) {
			egoera = true;
		}
		return egoera;
	}
	
	public boolean bezeroTelefonoaKonprobatu(String Telefonoa) throws SQLException {
		boolean egoera = false;
		if (Bezeroa.telefonoaKonprobatu(Telefonoa)) {
			egoera = true;
		}
		return egoera;
	}
	
	public boolean bezeroErabiltzaileaKonprobatu(String Erab) throws SQLException {
		boolean egoera = false;
		if (Bezeroa.erabiltzaileaKonprobatu(Erab)) {
			egoera = true;
		}
		return egoera;
	}
	
	public boolean bezeroEmailaKonprobatu(String Emaila) throws SQLException {
		boolean egoera = false;
		if (Bezeroa.emailaKonprobatu(Emaila)) {
			egoera = true;
		}
		return egoera;
	}
	
	public boolean langileTelefonoaKonprobatu(String Telefonoa) throws SQLException {
		boolean egoera = false;
		if (Langilea.telefonoaKonprobatu(Telefonoa)) {
			egoera = true;
		}
		return egoera;
	}
	
	public boolean herriIzenaKonprobatu(String izena) throws SQLException {
		boolean egoera = false;
		if (Herria.herriaKonprobatu(izena)) {
			egoera = true;
		}
		return egoera;
	}
	
	public void loginEgin(String Erab, String Pasa, JFrame loginWindow) {
		
		Langilea langilea = new Langilea();
        langilea.setErabiltzailea(Erab);
        langilea.setPasahitza(Pasa);
        System.out.println(langilea.getErabiltzailea()+" "+Pasa);
        langilea.saioaHasi(langilea.getErabiltzailea(), langilea.getPasahitza(), loginWindow);
        
	}
	
	public Langilea langileaKonprobatu(int idLangilea) {
	    Langilea langilea = Langilea.langileaBilatu(idLangilea);
	    
	    if (langilea == null) {
	        JOptionPane.showMessageDialog(null, "Ez da langilea aurkitu: " + idLangilea, "Errorea", JOptionPane.WARNING_MESSAGE);
	    }
	    
	    return langilea;
	}
	
	public boolean ezabatuLangilea(int idLangilea) {
		boolean ongiEzabatu = false;
		Langilea langilea = new Langilea();
    	if (langilea.langileaEzabatu(idLangilea)) {
    		ongiEzabatu = true;
    	}
    	return ongiEzabatu;
    }
	
	public boolean erregistroaKomprobatu(JTable tabla, int row) {
		if (tabla == null || row < 0 || row >= tabla.getRowCount()) {
	        return false;
	    }

	    for (int col = 0; col < tabla.getColumnCount(); col++) {
	        if (tabla.getValueAt(row, col) != null) {
	            return true;
	        }
	    }

	    return false;
	}
	
	public Bezeroa bezeroaKonprobatu(int idBezeroa) {
		Bezeroa bezeroa = Bezeroa.bezeroaBilatu(idBezeroa);
		
		if (bezeroa == null) {
			JOptionPane.showMessageDialog(null, "Ez da bezeroa aurkitu: " + idBezeroa, "Errorea", JOptionPane.WARNING_MESSAGE);
		}
		return bezeroa;
	}
	
	public boolean ezabatuBezeroa(int idBezeroa) {
		boolean ongiEzabatu = false;
		Bezeroa bezeroa = new Bezeroa();
		if (bezeroa.bezeroaEzabatu(idBezeroa)) {
			ongiEzabatu = true;
		}
		return ongiEzabatu;
	}

	public boolean eguneratuLangilea(Langilea langilea) {
		boolean ongiEguneratu = false;
		if (langilea.eguneratuLangilea(langilea)) {
			ongiEguneratu = true;
		}
		return ongiEguneratu;
	}
	
	public boolean eguneratuBezeroa(Bezeroa bezeroa) {
		boolean ongiEguneratu = false;
		try {
			if (bezeroa.eguneratuBezeroa(bezeroa)) {
				ongiEguneratu = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ongiEguneratu;
	}
	
	public boolean ezabatuHerria(int idHerria) {
		boolean ongiEzabatu = false;
		Herria herria = new Herria();
		if (herria.herriaEzabatu(idHerria)) {
			ongiEzabatu = true;
		}
		return ongiEzabatu;
	}

	public Herria herriaKonprobatu(int idHerria) {
		
		Herria bezeroa = Herria.herriaBilatu(idHerria);
		
		if (bezeroa == null) {
			JOptionPane.showMessageDialog(null, "Ez da herria aurkitu: " + idHerria, "Errorea", JOptionPane.WARNING_MESSAGE);
		}
		return bezeroa;
	}

	public boolean eguneratuHerria(Herria herria) {
		boolean ongiEguneratu = false;
		try {
			if (herria.eguneratuHerria(herria)) {
				ongiEguneratu = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ongiEguneratu;
	}

	public Ekintza ekintzaKonprobatu(int idEkintza) {
		Ekintza ekintza = Ekintza.ekintzaBilatu(idEkintza);
	    
	    if (ekintza == null) {
	        JOptionPane.showMessageDialog(null, "Ez da langilea aurkitu: " + idEkintza, "Errorea", JOptionPane.WARNING_MESSAGE);
	    }
	    
	    return ekintza;
	}
	
	public boolean ezabatuEkintza(int idEkintza) {
		boolean ongiEzabatu = false;
		Ekintza ekintza = new Ekintza();
    	if (ekintza.ekintzaEzabatu(idEkintza)) {
    		ongiEzabatu = true;
    	}
    	return ongiEzabatu;
    }

	public boolean eguneratuEkintza(Ekintza ekintza) {
		boolean ongiEguneratu = false;
		if (ekintza.eguneratuEkintza(ekintza)) {
			ongiEguneratu = true;
		}
		return ongiEguneratu;
	}
	
}
