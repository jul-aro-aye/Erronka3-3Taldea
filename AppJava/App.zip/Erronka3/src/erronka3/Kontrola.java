package erronka3;

public class Kontrola {

}
