package erronka3;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import erronka3.Konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField txtPasa;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 404);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblErab = new JLabel("Erabiltzailea:");
		lblErab.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblErab.setBounds(79, 195, 120, 30);
		contentPane.add(lblErab);
		
		txtPasa = new JPasswordField();
		txtPasa.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtPasa.setBounds(499, 200, 115, 25);
		contentPane.add(txtPasa);
		
		JTextArea txtErab = new JTextArea();
		txtErab.setBounds(199, 200, 115, 25);
		contentPane.add(txtErab);
		
		JLabel lblPasa = new JLabel("Pasahitza:");
		lblPasa.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPasa.setBounds(379, 195, 120, 30);
		contentPane.add(lblPasa);
		
		JButton btnSaioaHasi = new JButton("Saioa Hasi");
		btnSaioaHasi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Konexioa konexioa = new Konexioa("jdbc:mysql://172.16.237.151:3306/3erronka", "administratzailea",
				//		"1MG3@2024");
				Konexioa konexioa = new Konexioa("jdbc:mysql://localhost:3306/3erronka", "root", "1MG2024");
				Connection konexioadb;
				try {
				    konexioadb = konexioa.getConnection();
				    
				    Langilea lang = new Langilea();
				    System.out.println("Langilea sortuta eta konexioa eginda");

				    lang.setErabiltzailea(txtErab.getText());
				    char[] pasahitzaSaiakera = txtPasa.getPassword();
				    lang.setPasahitza(pasahitzaSaiakera);

				    String kontsultaErab = "SELECT erabiltzailea, pasahitza, kargua FROM 3erronka.langilea WHERE erabiltzailea = ?";

				    try (PreparedStatement ps = konexioadb.prepareStatement(kontsultaErab)) {
				        ps.setString(1, lang.getErabiltzailea());
				        System.out.println("Kontsulta eginda");

				        try (ResultSet emaitza = ps.executeQuery()) {
				            if (emaitza.next()) {
				                String erabiltzaileaDB = emaitza.getString("erabiltzailea");
				                String pasahitzaDB = emaitza.getString("pasahitza");
				                String karguaDb = emaitza.getString("kargua");
				                System.out.println("Datu basetik irakurtzen");

				                String pasahitzaSaiakeraStr = new String(pasahitzaSaiakera);

				                if (pasahitzaSaiakeraStr.equals(pasahitzaDB)) {
				                    if ("Admin".equals(karguaDb)) {
				                        System.out.println("Admin da!");
				                        MenuAdmin menuAdmin = new MenuAdmin();
				                        menuAdmin.setVisible(true);
				                    } else if ("Langi".equals(karguaDb)) {
				                        MenuLangi menuLangi = new MenuLangi();
				                        menuLangi.setVisible(true);
				                    }
				                } else {
				                    JOptionPane.showMessageDialog(null, "Erabiltzaile eta pasahitz okerrak", "Arazoak",
				                            JOptionPane.INFORMATION_MESSAGE);
				                }
				            } else {
				                JOptionPane.showMessageDialog(null, "Erabiltzailea ez da existitzen", "Arazoak",
				                        JOptionPane.INFORMATION_MESSAGE);
				            }
				        }
				    }
				} catch (SQLException e1) {
				    e1.printStackTrace();
				}

				
			}
		});
		btnSaioaHasi.setBackground(new Color(128, 255, 128));
		btnSaioaHasi.setBounds(281, 269, 129, 48);
		contentPane.add(btnSaioaHasi);
		
		JLabel lblIzenburua = new JLabel("Ongi etorri AeroPark App-era");
		lblIzenburua.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblIzenburua.setBounds(126, 39, 488, 101);
		contentPane.add(lblIzenburua);
	}
}
