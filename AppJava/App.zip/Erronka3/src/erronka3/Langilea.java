package erronka3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JFrame;

public class Langilea {
	private int idLangilea;
	private String izena;
	private String abizenak;
	private String Erabiltzailea;
	private char[] Pasahitza;
	private String telefonoa;
	private String emaila;
	private String kargua;
	Connection konexioadb;
	
	public Langilea(String erabiltzailea, char[] pasahitza) {
		Erabiltzailea = erabiltzailea;
		Pasahitza = pasahitza;
	}

	public Langilea(int idLangilea, String izena, String abizenak, String erabiltzailea, char[] pasahitza,
			String telefonoa, String emaila, String kargua) {
		this.idLangilea = idLangilea;
		this.izena = izena;
		this.abizenak = abizenak;
		Erabiltzailea = erabiltzailea;
		Pasahitza = pasahitza;
		this.telefonoa = telefonoa;
		this.emaila = emaila;
		this.kargua = kargua;
	}

	public Langilea(int idLangilea, String izena, String abizenak, String erabiltzailea, char[] pasahitza,
			String telefonoa, String kargua) {
		this.idLangilea = idLangilea;
		this.izena = izena;
		this.abizenak = abizenak;
		Erabiltzailea = erabiltzailea;
		Pasahitza = pasahitza;
		this.telefonoa = telefonoa;
		this.kargua = kargua;
	}
	
	public Langilea() {
		
	}

	/**
	 * @return the idLangilea
	 */
	public int getIdLangilea() {
		return idLangilea;
	}

	/**
	 * @param idLangilea the idLangilea to set
	 */
	public void setIdLangilea(int idLangilea) {
		this.idLangilea = idLangilea;
	}

	/**
	 * @return the izena
	 */
	public String getIzena() {
		return izena;
	}

	/**
	 * @param izena the izena to set
	 */
	public void setIzena(String izena) {
		this.izena = izena;
	}

	/**
	 * @return the abizenak
	 */
	public String getAbizenak() {
		return abizenak;
	}

	/**
	 * @param abizenak the abizenak to set
	 */
	public void setAbizenak(String abizenak) {
		this.abizenak = abizenak;
	}

	/**
	 * @return the erabiltzailea
	 */
	public String getErabiltzailea() {
		return Erabiltzailea;
	}

	/**
	 * @param erabiltzailea the erabiltzailea to set
	 */
	public void setErabiltzailea(String erabiltzailea) {
		Erabiltzailea = erabiltzailea;
	}

	/**
	 * @return the pasahitza
	 */
	public char[] getPasahitza() {
		return Pasahitza;
	}

	/**
	 * @param pasahitza the pasahitza to set
	 */
	public void setPasahitza(char[] pasahitza) {
		Pasahitza = pasahitza;
	}

	/**
	 * @return the telefonoa
	 */
	public String getTelefonoa() {
		return telefonoa;
	}

	/**
	 * @param telefonoa the telefonoa to set
	 */
	public void setTelefonoa(String telefonoa) {
		this.telefonoa = telefonoa;
	}

	/**
	 * @return the emaila
	 */
	public String getEmaila() {
		return emaila;
	}

	/**
	 * @param emaila the emaila to set
	 */
	public void setEmaila(String emaila) {
		this.emaila = emaila;
	}

	/**
	 * @return the kargua
	 */
	public String getKargua() {
		return kargua;
	}

	/**
	 * @param kargua the kargua to set
	 */
	public void setKargua(String kargua) {
		this.kargua = kargua;
	}
	
	public void LoginEgin(String erabiltzailea2, char[] pasahitza2, JFrame Login) {
	    Konexioa konexioa = new Konexioa("jdbc:mysql://localhost:3306/3erronka", "root", "1MG2024");
	  //Konexioa konexioa = new Konexioa("jdbc:mysql://172.16.237.151:3306/3erronka", "administratzailea",
		//		"1MG3@2024");
	    try {
	        Connection konexioadb = konexioa.getConnection();
	        String kontsultaErab = "SELECT erabiltzailea, pasahitza, kargua FROM 3erronka.langilea WHERE erabiltzailea = ?";

	        try (PreparedStatement ps = konexioadb.prepareStatement(kontsultaErab)) {
	            ps.setString(1, erabiltzailea2);

	            try (ResultSet emaitza = ps.executeQuery()) {
	                if (emaitza.next()) {
	                    String erabiltzaileaDB = emaitza.getString("erabiltzailea");
	                    String pasahitzaDB = emaitza.getString("pasahitza");
	                    String karguaDb = emaitza.getString("kargua");

	                    String pasahitzaSaiakeraStr = new String(pasahitza2);

	                    if (pasahitzaSaiakeraStr.equals(pasahitzaDB)) {
	                        if ("Admin".equals(karguaDb)) {
	                        	Login.dispose();
	                            MenuAdmin menuAdmin = new MenuAdmin();
	                            menuAdmin.setVisible(true);
	                        } else if ("Langi".equals(karguaDb)) {
	                        	Login.dispose();
	                            MenuLangi menuLangi = new MenuLangi();
	                            menuLangi.setVisible(true);
	                        }
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Erabiltzaile eta pasahitz okerrak", "Arazoak", JOptionPane.INFORMATION_MESSAGE);
	                    }
	                } else {
	                    JOptionPane.showMessageDialog(null, "Erabiltzailea ez da existitzen", "Errorea", JOptionPane.ERROR_MESSAGE);
	                }
	            }
	        }
	    } catch (SQLException e1) {
	        JOptionPane.showMessageDialog(null, "Arazoak datu basera konektattzean", "Error", JOptionPane.ERROR_MESSAGE);
	        e1.printStackTrace();
	    }
	}
	
}
