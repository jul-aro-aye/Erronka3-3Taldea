package erronka3;

public class Langilea {
	private int idLangilea;
	private String izena;
	private String abizenak;
	private String Erabiltzailea;
	private char[] Pasahitza;
	private String telefonoa;
	private String emaila;
	private String kargua;
	
	public Langilea(String erabiltzailea, char[] pasahitza) {
		Erabiltzailea = erabiltzailea;
		Pasahitza = pasahitza;
	}

	public Langilea(int idLangilea, String izena, String abizenak, String erabiltzailea, char[] pasahitza,
			String telefonoa, String emaila, String kargua) {
		this.idLangilea = idLangilea;
		this.izena = izena;
		this.abizenak = abizenak;
		Erabiltzailea = erabiltzailea;
		Pasahitza = pasahitza;
		this.telefonoa = telefonoa;
		this.emaila = emaila;
		this.kargua = kargua;
	}

	public Langilea(int idLangilea, String izena, String abizenak, String erabiltzailea, char[] pasahitza,
			String telefonoa, String kargua) {
		this.idLangilea = idLangilea;
		this.izena = izena;
		this.abizenak = abizenak;
		Erabiltzailea = erabiltzailea;
		Pasahitza = pasahitza;
		this.telefonoa = telefonoa;
		this.kargua = kargua;
	}
	
	public Langilea() {
		
	}

	/**
	 * @return the idLangilea
	 */
	public int getIdLangilea() {
		return idLangilea;
	}

	/**
	 * @param idLangilea the idLangilea to set
	 */
	public void setIdLangilea(int idLangilea) {
		this.idLangilea = idLangilea;
	}

	/**
	 * @return the izena
	 */
	public String getIzena() {
		return izena;
	}

	/**
	 * @param izena the izena to set
	 */
	public void setIzena(String izena) {
		this.izena = izena;
	}

	/**
	 * @return the abizenak
	 */
	public String getAbizenak() {
		return abizenak;
	}

	/**
	 * @param abizenak the abizenak to set
	 */
	public void setAbizenak(String abizenak) {
		this.abizenak = abizenak;
	}

	/**
	 * @return the erabiltzailea
	 */
	public String getErabiltzailea() {
		return Erabiltzailea;
	}

	/**
	 * @param erabiltzailea the erabiltzailea to set
	 */
	public void setErabiltzailea(String erabiltzailea) {
		Erabiltzailea = erabiltzailea;
	}

	/**
	 * @return the pasahitza
	 */
	public char[] getPasahitza() {
		return Pasahitza;
	}

	/**
	 * @param pasahitza the pasahitza to set
	 */
	public void setPasahitza(char[] pasahitza) {
		Pasahitza = pasahitza;
	}

	/**
	 * @return the telefonoa
	 */
	public String getTelefonoa() {
		return telefonoa;
	}

	/**
	 * @param telefonoa the telefonoa to set
	 */
	public void setTelefonoa(String telefonoa) {
		this.telefonoa = telefonoa;
	}

	/**
	 * @return the emaila
	 */
	public String getEmaila() {
		return emaila;
	}

	/**
	 * @param emaila the emaila to set
	 */
	public void setEmaila(String emaila) {
		this.emaila = emaila;
	}

	/**
	 * @return the kargua
	 */
	public String getKargua() {
		return kargua;
	}

	/**
	 * @param kargua the kargua to set
	 */
	public void setKargua(String kargua) {
		this.kargua = kargua;
	}
	
	
	
}
