package erronka3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Konexioa {
	private String url;
	private String erabiltzailea;
	private String pasahitza;
	private Connection conn;

	public Konexioa(String url, String erabiltzailea, String pasahitza) {
		this.url = url;
		this.erabiltzailea = erabiltzailea;
		this.pasahitza = pasahitza;
	}

	public Connection getConnection() throws SQLException {
		try {
			Connection conn = DriverManager.getConnection(url, erabiltzailea, pasahitza);
			return conn;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Arazoak datu basearekin konexioa egitean.", "Errorea",
					JOptionPane.ERROR_MESSAGE);
			throw new RuntimeException("Arazoak datu basearekin konektatzean", e);
		}
	}
	
	public void itxiKonexioa() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                JOptionPane.showMessageDialog(null, "Konexioa itxi da.", "Informazioa", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
        	JOptionPane.showMessageDialog(null, "Arazoak konexioa ixtean.", "Arazoak", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
