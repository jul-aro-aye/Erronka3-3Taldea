/**
 * 
 */
/**
 * 
 */
module Erronka3 {
	requires java.desktop;
	requires java.sql;
}